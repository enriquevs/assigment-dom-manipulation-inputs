document.querySelector("#reset-field-btn").addEventListener('click', function(){
      // TASK #1
  })


document.querySelector("#validate-field-btn").addEventListener('click',function(){
  // TASK #2

})


document.querySelector("#calculate-items-btn").addEventListener('click', function(){
  // TASK #3
})


document.querySelector("#select-to-show-more-btn").addEventListener('click', function(){
  // TASK #4
})
